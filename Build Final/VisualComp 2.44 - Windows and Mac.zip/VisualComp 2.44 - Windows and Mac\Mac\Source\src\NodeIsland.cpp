#include "NodeIsland.h"
#include "Theme.h"

NodeIsland::NodeIsland(VisualCompProcessor& proc) : processor(proc)
{
    // Load any previously-saved Island positions from processor state
    syncPositionsFromProcessor();

    qKnob.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    qKnob.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    qKnob.setRange(0.15, 10.0);
    qKnob.setSkewFactor(0.4);
    qKnob.setDoubleClickReturnValue(true, 0.9);
    qKnob.setMouseDragSensitivity(700);
    qKnob.onValueChange = [this]
    {
        if (target < 0) return;
        auto n = processor.eq.getNode(target);
        const float newQ = float(qKnob.getValue());
        const float ratio = (n.q > 0.0001f) ? newQ / n.q : 1.0f;
        n.q = newQ;
        processor.eq.setNode(target, n);
        if (onQRatioChanged) onQRatioChanged(target, ratio);
        if (onNodeEdited) onNodeEdited(target);
    };
    addAndMakeVisible(qKnob);

    qLabel.setText("Q", juce::dontSendNotification);
    qLabel.setJustificationType(juce::Justification::centred);
    qLabel.setFont(Theme::label(11.0f));
    qLabel.setColour(juce::Label::textColourId, Theme::screenText.withAlpha(0.86f));
    qLabel.setInterceptsMouseClicks(false, false);
    addAndMakeVisible(qLabel);

    // FabFilter Pro-MB style: downward-only (0..-60dB — same value as the
    // graph's "T" marker, see EqPanel::thresholdMarkerPos). Skewed range —
    // see setupThresholdKnobRange() in EqEngine.h.
    thresholdKnob.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    thresholdKnob.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    setupThresholdKnobRange(thresholdKnob);
    thresholdKnob.setDoubleClickReturnValue(true, -20.0);
    thresholdKnob.setMouseDragSensitivity(700);
    thresholdKnob.onValueChange = [this]
    {
        if (target < 0) return;
        auto n = processor.eq.getNode(target);
        const float oldThreshold = n.thresholdDb;
        const float newThreshold = float(thresholdKnob.getValue());
        const float delta = newThreshold - oldThreshold;
        n.thresholdDb = newThreshold;
        processor.eq.setNode(target, n);
        if (onThresholdChanged) onThresholdChanged(target, delta);
        if (onNodeEdited) onNodeEdited(target);
    };
    addAndMakeVisible(thresholdKnob);

    thresholdLabel.setText("THR", juce::dontSendNotification);
    thresholdLabel.setJustificationType(juce::Justification::centred);
    thresholdLabel.setFont(Theme::label(11.0f));
    thresholdLabel.setColour(juce::Label::textColourId, Theme::screenText.withAlpha(0.86f));
    thresholdLabel.setInterceptsMouseClicks(false, false);
    addAndMakeVisible(thresholdLabel);

    // FabFilter Pro-MB style: +/-30dB, clamping how far this band's dynamics
    // can swing the gain (see clampedDynamicGrDb) — and its sign chooses
    // downward vs upward, same as Pro-MB's own Range knob. The range is
    // already symmetric about 0 so no extra skew work is needed to keep
    // 0dB dead-centre. The glow ring fills from centre outward (see
    // AzazelLookAndFeel::drawRotarySlider's "centerFill" property) rather
    // than from one end, matching a bipolar knob's actual travel.
    rangeKnob.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    rangeKnob.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    rangeKnob.setRange(-30.0, 30.0);
    rangeKnob.setDoubleClickReturnValue(true, 0.0);
    rangeKnob.setMouseDragSensitivity(700);
    rangeKnob.getProperties().set("centerFill", true);
    rangeKnob.onValueChange = [this]
    {
        if (target < 0) return;
        auto n = processor.eq.getNode(target);
        const float oldRange = n.rangeDb;
        const float newRange = float(rangeKnob.getValue());
        const float delta = newRange - oldRange;
        n.rangeDb = newRange;
        // Range's sign directly drives direction, live, every time it's
        // touched — positive is always Upward, negative (or zero) is always
        // Downward. The direction button below still works as a one-off
        // manual override, but the next Range tweak snaps it back in line.
        n.upward = n.rangeDb > 0.0f;
        processor.eq.setNode(target, n);
        directionButton.setToggleState(n.upward, juce::dontSendNotification);
        directionButton.setButtonText(n.upward ? "UP" : "DOWN");
        if (onRangeChanged) onRangeChanged(target, delta);
        if (onNodeEdited) onNodeEdited(target);
    };
    addAndMakeVisible(rangeKnob);

    rangeLabel.setText("RANGE", juce::dontSendNotification);
    rangeLabel.setJustificationType(juce::Justification::centred);
    rangeLabel.setFont(Theme::label(11.0f));
    rangeLabel.setColour(juce::Label::textColourId, Theme::screenText.withAlpha(0.86f));
    rangeLabel.setInterceptsMouseClicks(false, false);
    addAndMakeVisible(rangeLabel);

    // Node's own x-axis position on the graph (20Hz..20kHz, log-skewed about
    // 1kHz to match the graph's own log frequency axis).
    freqKnob.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    freqKnob.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    freqKnob.setRange(20.0, 20000.0);
    freqKnob.setSkewFactorFromMidPoint(1000.0);
    freqKnob.setDoubleClickReturnValue(true, 1000.0);
    freqKnob.setMouseDragSensitivity(700);
    freqKnob.onValueChange = [this]
    {
        if (target < 0) return;
        auto n = processor.eq.getNode(target);
        const float oldFreq = n.freqHz;
        const float newFreq = float(freqKnob.getValue());
        const float ratio = (oldFreq > 0.0f) ? newFreq / oldFreq : 1.0f;
        n.freqHz = newFreq;
        processor.eq.setNode(target, n);
        if (onFreqChanged) onFreqChanged(target, ratio);
        if (onNodeEdited) onNodeEdited(target);
    };
    addAndMakeVisible(freqKnob);

    freqLabel.setText("FREQ", juce::dontSendNotification);
    freqLabel.setJustificationType(juce::Justification::centred);
    freqLabel.setFont(Theme::label(11.0f));
    freqLabel.setColour(juce::Label::textColourId, Theme::screenText.withAlpha(0.86f));
    freqLabel.setInterceptsMouseClicks(false, false);
    addAndMakeVisible(freqLabel);

    // Node's own y-axis position on the graph. Range matches EqPanel's own
    // kGainRange (+/-18dB); no-op for HPF/LPF/Notch, which stay pinned to
    // 0dB the same way the graph itself refuses to drag them vertically
    // (see EqTypes::isGainlessType).
    gainKnob.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    gainKnob.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    gainKnob.setRange(-18.0, 18.0);
    gainKnob.setDoubleClickReturnValue(true, 0.0);
    gainKnob.setMouseDragSensitivity(700);
    gainKnob.getProperties().set("centerFill", true);
    gainKnob.onValueChange = [this]
    {
        if (target < 0) return;
        auto n = processor.eq.getNode(target);
        if (EqTypes::isGainlessType(n.type)) return;
        const float oldGain = n.gainDb;
        const float newGain = float(gainKnob.getValue());
        const float delta = newGain - oldGain;
        n.gainDb = newGain;
        processor.eq.setNode(target, n);
        if (onGainChanged) onGainChanged(target, delta);
        if (onNodeEdited) onNodeEdited(target);
    };
    addAndMakeVisible(gainKnob);

    gainLabel.setText("GAIN", juce::dontSendNotification);
    gainLabel.setJustificationType(juce::Justification::centred);
    gainLabel.setFont(Theme::label(11.0f));
    gainLabel.setColour(juce::Label::textColourId, Theme::screenText.withAlpha(0.86f));
    gainLabel.setInterceptsMouseClicks(false, false);
    addAndMakeVisible(gainLabel);

    // Manual override for the direction Range's sign already implies (see
    // EqNodeState::upward).
    directionButton.setClickingTogglesState(true);
    directionButton.setColour(juce::TextButton::buttonColourId,   Theme::buttonFace);
    directionButton.setColour(juce::TextButton::buttonOnColourId, Theme::buttonPressed);
    directionButton.setColour(juce::TextButton::textColourOffId,  Theme::screenTextDim);
    directionButton.setColour(juce::TextButton::textColourOnId,   Theme::buttonText);
    directionButton.onClick = [this]
    {
        if (target < 0) return;
        auto n = processor.eq.getNode(target);
        n.upward = directionButton.getToggleState();
        processor.eq.setNode(target, n);
        directionButton.setButtonText(n.upward ? "UP" : "DOWN");
        if (onNodeEdited) onNodeEdited(target);
    };
    addAndMakeVisible(directionButton);

    // Toggles EqNodeState::linked — same field the graph's right-click
    // "Link to Compressor" menu item controls. AzazelLookAndFeel's
    // drawButtonBackground owns the shared seated-cap treatment.  Keep the
    // legend light on the dark face in both states; the latched state is
    // carried by the cap depth and compact accent marker.
    compButton.setClickingTogglesState(true);
    compButton.setButtonText("COMP");
    compButton.setColour(juce::TextButton::textColourOffId, Theme::screenTextDim);
    compButton.setColour(juce::TextButton::textColourOnId,  Theme::buttonText);
    compButton.onClick = [this]
    {
        if (target < 0) return;
        const bool linked = compButton.getToggleState();

        // EqPanel owns the graph-local node copy and detector-edge junctions,
        // so let it perform the same complete operation as its context menu.
        // Keep a direct-write fallback for any future standalone use.
        if (onLinkedToggled)
            onLinkedToggled(target, linked);
        else
        {
            auto n = processor.eq.getNode(target);
            n.linked = linked;
            processor.eq.setNode(target, n);
            if (onNodeEdited) onNodeEdited(target);
        }
    };
    addAndMakeVisible(compButton);

    typeButton.setColour(juce::TextButton::buttonColourId,  Theme::buttonFace);
    typeButton.setColour(juce::TextButton::textColourOffId, Theme::buttonText);
    typeButton.onClick = [this] { showTypeMenu(); };
    addAndMakeVisible(typeButton);

    setVisible(false);
}

void NodeIsland::setTargetNode(int index)
{
    if (index != target)
    {
        userMoved = false;   // new node: re-dock under it by default
        target = index;
        // Try to restore any previously-saved position for this node
        if (index >= 0)
            restoreSavedPosition();
    }
    else
    {
        target = index;
    }
    setVisible(index >= 0);
    if (index >= 0)
    {
        refreshFromProcessor();
        syncPositionsToProcessor();  // Ensure processor state is current
    }
}

void NodeIsland::mouseDown(const juce::MouseEvent& e)
{
    // Only reached for clicks that land on the Island's own background --
    // every knob/button consumes its own clicks, so this is naturally
    // "anywhere that's not a button or input".
    dragAnchor = e.getPosition();
}

void NodeIsland::mouseDrag(const juce::MouseEvent& e)
{
    auto* parent = getParentComponent();
    if (parent == nullptr) return;

    auto pos = getPosition() + (e.getPosition() - dragAnchor);
    const auto bounds = parent->getLocalBounds();
    pos.x = juce::jlimit(bounds.getX(), juce::jmax(bounds.getX(), bounds.getRight() - getWidth()),  pos.x);
    pos.y = juce::jlimit(bounds.getY(), juce::jmax(bounds.getY(), bounds.getBottom() - getHeight()), pos.y);
    setTopLeftPosition(pos);
    userMoved = true;
    saveCurrentNodePosition();
    syncPositionsToProcessor();
}

void NodeIsland::refreshFromProcessor()
{
    if (target < 0) return;
    const auto n = processor.eq.getNode(target);
    if (!qKnob.isMouseButtonDown())
        qKnob.setValue(n.q, juce::dontSendNotification);
    if (!thresholdKnob.isMouseButtonDown())
        thresholdKnob.setValue(n.thresholdDb, juce::dontSendNotification);
    if (!rangeKnob.isMouseButtonDown())
        rangeKnob.setValue(n.rangeDb, juce::dontSendNotification);
    if (!freqKnob.isMouseButtonDown())
        freqKnob.setValue(n.freqHz, juce::dontSendNotification);
    // HPF/LPF/Notch have no static gain to edit -- pin the knob at 0dB and
    // disable it outright (rather than merely ignoring drags in
    // onValueChange) so it can't visually drift away from 0 mid-drag only to
    // snap back on the next poll tick once released.
    const bool gainEditable = !EqTypes::isGainlessType(n.type);
    gainKnob.setEnabled(gainEditable);
    if (!gainKnob.isMouseButtonDown())
        gainKnob.setValue(gainEditable ? n.gainDb : 0.0f, juce::dontSendNotification);
    directionButton.setToggleState(n.upward, juce::dontSendNotification);
    directionButton.setButtonText(n.upward ? "UP" : "DOWN");
    compButton.setToggleState(n.linked, juce::dontSendNotification);
    typeButton.setButtonText(EqTypes::kNames[juce::jlimit(0, EqTypes::kNumTypes - 1, n.type)]);
}

void NodeIsland::showTypeMenu()
{
    if (target < 0) return;
    const int t = target;
    const auto n = processor.eq.getNode(t);

    juce::PopupMenu menu;
    menu.setLookAndFeel(&getLookAndFeel());
    for (int i = 0; i < EqTypes::kNumTypes; ++i)
        menu.addItem(100 + i, EqTypes::kNames[i], true, n.type == i);

    menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(typeButton),
        [this, t](int result)
        {
            if (result < 100) return;
            auto node = processor.eq.getNode(t);
            node.type = result - 100;
            processor.eq.setNode(t, node);
            if (onNodeEdited) onNodeEdited(t);
            if (t == target) refreshFromProcessor();
        });
}

void NodeIsland::resized()
{
    auto r = getLocalBounds().reduced(9, 8);

    auto knobRow = r.removeFromTop(66);
    auto qArea = knobRow.removeFromLeft(54);
    qLabel.setBounds(qArea.removeFromTop(13));
    qKnob.setBounds(qArea);

    knobRow.removeFromLeft(6);
    auto thrArea = knobRow.removeFromLeft(54);
    thresholdLabel.setBounds(thrArea.removeFromTop(13));
    thresholdKnob.setBounds(thrArea);

    knobRow.removeFromLeft(6);
    auto rangeArea = knobRow.removeFromLeft(54);
    rangeLabel.setBounds(rangeArea.removeFromTop(13));
    rangeKnob.setBounds(rangeArea);

    knobRow.removeFromLeft(6);
    auto freqArea = knobRow.removeFromLeft(54);
    freqLabel.setBounds(freqArea.removeFromTop(13));
    freqKnob.setBounds(freqArea);

    knobRow.removeFromLeft(6);
    auto gainArea = knobRow.removeFromLeft(54);
    gainLabel.setBounds(gainArea.removeFromTop(13));
    gainKnob.setBounds(gainArea);

    knobRow.removeFromLeft(6);
    compButton.setBounds(knobRow.getX(), knobRow.getCentreY() - 13, knobRow.getWidth(), 26);

    r.removeFromTop(6);
    auto dirArea = r.removeFromLeft(90);
    directionButton.setBounds(dirArea.getX(), r.getCentreY() - 13, dirArea.getWidth(), 26);

    r.removeFromLeft(6);
    typeButton.setBounds(r.getX(), r.getCentreY() - 13, r.getWidth(), 26);
}

void NodeIsland::paint(juce::Graphics& g)
{
    const auto r = getLocalBounds().toFloat().reduced(1.0f);

    g.setColour(juce::Colours::black.withAlpha(0.52f));
    g.fillRoundedRectangle(r.translated(0.0f, 2.0f), 10.0f);

    juce::ColourGradient shell(Theme::buttonHover, r.getX(), r.getY(),
                                Theme::buttonPressed, r.getRight(), r.getBottom(), false);
    g.setGradientFill(shell);
    g.fillRoundedRectangle(r, 10.0f);

    g.setColour(juce::Colours::white.withAlpha(0.24f));
    g.drawLine(r.getX() + 10.0f, r.getY() + 0.7f,
               r.getRight() - 10.0f, r.getY() + 0.7f, 1.0f);
    g.drawLine(r.getX() + 0.7f, r.getY() + 10.0f,
               r.getX() + 0.7f, r.getBottom() - 10.0f, 1.0f);

    g.setColour(juce::Colours::black.withAlpha(0.46f));
    g.drawLine(r.getX() + 10.0f, r.getBottom() - 0.7f,
               r.getRight() - 10.0f, r.getBottom() - 0.7f, 1.0f);
    g.drawLine(r.getRight() - 0.7f, r.getY() + 10.0f,
               r.getRight() - 0.7f, r.getBottom() - 10.0f, 1.0f);

    g.setColour(juce::Colours::black.withAlpha(0.82f));
    g.drawRoundedRectangle(r, 10.0f, 0.8f);
}

void NodeIsland::saveCurrentNodePosition()
{
    if (target < 0 || target >= kMaxEqNodes) return;
    savedPositions[target].x = getX();
    savedPositions[target].y = getY();
    savedPositions[target].hasPosition = true;
}

void NodeIsland::restoreSavedPosition()
{
    if (target < 0 || target >= kMaxEqNodes) return;
    if (savedPositions[target].hasPosition)
    {
        setTopLeftPosition(savedPositions[target].x, savedPositions[target].y);
        userMoved = true;
    }
}

void NodeIsland::syncPositionsFromProcessor()
{
    // Load Island positions from processor's persisted state
    for (int i = 0; i < kMaxEqNodes; ++i)
    {
        savedPositions[i] = processor.islandPositions[i];
    }
}

void NodeIsland::syncPositionsToProcessor()
{
    // Save Island positions to processor's persisted state
    for (int i = 0; i < kMaxEqNodes; ++i)
    {
        processor.islandPositions[i] = savedPositions[i];
    }
}
