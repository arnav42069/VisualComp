﻿#include "PluginProcessor.h"
#include "PluginEditor.h"

static inline float fastTanh(float x) noexcept
{
    const float x2 = x * x;
    return x * (27.0f + x2) / (27.0f + 9.0f * x2);
}

static inline float fetSaturate(float x, float drive) noexcept
{
    const float k       = 1.0f + drive * 2.2f;
    const float clipped = fastTanh(x * k) / k;
    const float asym    = drive * 0.018f * clipped * std::abs(clipped);
    return clipped + asym;
}

static inline float tubeSaturate(float x, float drive) noexcept
{
    const float k   = 1.0f + drive * 1.6f;
    const float sat = std::tanh(x * k) / k;
    return sat + drive * 0.025f * sat * sat;
}

VisualCompProcessor::VisualCompProcessor()
    : AudioProcessor(BusesProperties()
          .withInput ("Input",     juce::AudioChannelSet::stereo(), true)
          .withInput ("Sidechain", juce::AudioChannelSet::stereo(), false)
          .withOutput("Output",    juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "STATE", createParameterLayout())
{
}

VisualCompProcessor::~VisualCompProcessor() = default;

juce::AudioProcessorValueTreeState::ParameterLayout
VisualCompProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;
    // Defaults = "Mastering Glue" factory preset: transparent 2:1 bus glue
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"attack", 1}, "Attack",
        juce::NormalisableRange<float>(0.1f, 200.0f, 0.01f, 0.3f), 30.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"release", 1}, "Release",
        juce::NormalisableRange<float>(1.0f, 2000.0f, 0.1f, 0.3f), 100.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"threshold", 1}, "Threshold",
        juce::NormalisableRange<float>(-90.0f, 0.0f, 0.1f), -10.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"knee", 1}, "Knee",
        juce::NormalisableRange<float>(0.0f, 20.0f, 0.1f), 6.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"ratio", 1}, "Ratio",
        juce::NormalisableRange<float>(1.0f, 20.0f, 0.01f, 0.4f), 2.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"gainIn", 1}, "Gain In",
        juce::NormalisableRange<float>(-24.0f, 24.0f, 0.1f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"gainOut", 1}, "Gain Out",
        juce::NormalisableRange<float>(-24.0f, 24.0f, 0.1f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"limiter", 1}, "Limiter", false));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"mix", 1}, "Mix",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.001f), 1.0f));
    // EQ-only dry/wet, independent of the overall Mix above -- blends just
    // the parametric EQ's tone-shaping (see the per-sample loop's "EQ
    // dry/wet" block), not the compressor/saturation. Defaults to fully wet
    // (1.0) so every existing session/preset predating this parameter still
    // sounds identical after loading.
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"eqMix", 1}, "EQ Mix",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.001f), 1.0f));
    // Oversampling factor for the final clip/limit stage. A *choice* rather
    // than a float so a host automation lane can only ever land on a real
    // factor. Index -> factor is 1/2/4/8 (see oversamplingFactorForIndex);
    // index -> JUCE's Oversampling "numStages" argument is just the index
    // itself, since that argument counts 2x stages (log2 of the ratio).
    // Defaults to Off: changing the factor changes reported latency, so a
    // session predating this parameter must load with the same latency it
    // was mixed at.
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"oversamplingFactor", 1}, "Oversampling",
        juce::StringArray{ "1x (Off)", "2x", "4x", "8x" }, 0));
    return { params.begin(), params.end() };
}

int VisualCompProcessor::oversamplingFactorForIndex(int index) noexcept
{
    return 1 << juce::jlimit(0, kMaxOversamplingStages, index);
}

// Total latency reported to the host, in *base-rate* samples:
//
//   - the oversampler's own halfband filter delay. JUCE already expresses
//     this at the base rate (Oversampling::getUncompensatedLatency divides
//     each stage's latency by the cumulative factor at that stage), so it is
//     used as-is -- do NOT divide it again.
//   - the lookahead delay line, which runs *inside* the oversampler and so
//     is measured in oversampled samples; that one does need dividing.
//     OutputClipper::setSampleRate() is asked to quantise its lookahead to a
//     multiple of the factor, so this division is always exact and the host's
//     PDC lands on a whole sample.
int VisualCompProcessor::computeTotalLatency() const
{
    const int idx    = juce::jlimit(0, kMaxOversamplingStages,
                                    activeOversamplingIndex.load(std::memory_order_relaxed));
    const int factor = oversamplingFactorForIndex(idx);

    int osLatency = 0;
    if (idx > 0 && oversamplers[size_t(idx)] != nullptr)
        osLatency = int(std::round(oversamplers[size_t(idx)]->getLatencyInSamples()));

    return osLatency + clipper.getLatencySamples() / factor;
}

void VisualCompProcessor::handleAsyncUpdate()
{
    // Re-negotiating PDC with the host is emphatically not a real-time-safe
    // operation, so the audio thread only ever flags that the factor moved
    // and the message thread reports the new figure.
    setLatencySamples(computeTotalLatency());
}

bool VisualCompProcessor::loadDemoAudioFile(const juce::File& file)
{
    demoAudioPlaying.store(false, std::memory_order_release);
    demoAudioReady.store(false, std::memory_order_release);
    demoAudio.clear();
    if (!file.existsAsFile() || currentSampleRate <= 0.0)
        return false;

    juce::WavAudioFormat wav;
    auto stream = file.createInputStream();
    std::unique_ptr<juce::AudioFormatReader> reader(wav.createReaderFor(stream.release(), true));
    if (reader == nullptr || reader->lengthInSamples <= 0)
        return false;

    const int frames = int(juce::jmin<int64>(reader->lengthInSamples,
                                              60LL * 60LL * int64(reader->sampleRate)));
    demoAudio.setSize(juce::jmax(1, int(reader->numChannels)), frames, false, true, true);
    if (!reader->read(&demoAudio, 0, frames, 0, true, true))
    {
        demoAudio.clear();
        return false;
    }

    demoReadPosition = 0.0;
    demoReadIncrement = reader->sampleRate / currentSampleRate;
    demoAudioReady.store(true, std::memory_order_release);
    return true;
}

void VisualCompProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;
    envelope          = 0.0f;
    opticalState      = 0.0f;
    tubeMu            = 1.0f;
    inputRmsSmooth    = 0.0f;
    outputRmsSmooth   = 0.0f;
    scEnvelope        = 0.0f;
    autoGainDb        = 0.0f;
    // Standalone audio backends may occasionally deliver a callback larger
    // than the nominal block size passed here. JUCE's Oversampling scratch
    // storage must be prepared for the largest block processSamplesUp may
    // ever see or it can overwrite its heap buffer.
    preparedBlockCapacity = juce::jmax(8192, juce::jmax(1, samplesPerBlock));
    monoMixBuffer.setSize(1, preparedBlockCapacity);
    scEnvBuf     .setSize(1, preparedBlockCapacity);

    eq.prepare(sampleRate);
    for (auto& bg : bandGrDb) bg.store(0.0f, std::memory_order_relaxed);
    loudness.prepare(sampleRate);

    // Build every oversampler up front -- constructing one and calling
    // initProcessing() both allocate, so neither may happen in processBlock
    // when the user changes the factor. Index doubles as the stage count
    // (each stage is 2x, so index 3 == 2^3 == 8x); index 0 is never used, the
    // 1x path bypasses the whole stage.
    for (size_t i = 1; i < oversamplers.size(); ++i)
    {
        oversamplers[i] = std::make_unique<juce::dsp::Oversampling<float>>(
            2 /*channels*/, int(i) /*number of 2x stages*/,
            // Polyphase IIR, not the FIR equiripple: the FIR is linear phase,
            // which means symmetric pre-ringing *before* every transient --
            // exactly the overshoot a clipper exists to avoid. The IIR's phase
            // smear is inaudible here and its latency is a fraction of the FIR's.
            juce::dsp::Oversampling<float>::filterHalfBandPolyphaseIIR,
            true  /*maximum quality*/,
            true  /*integer latency -- keeps host PDC on whole samples*/);
        oversamplers[i]->initProcessing(size_t(preparedBlockCapacity));
        oversamplers[i]->reset();
    }

    // Reserve the delay line for the highest rate we can ever run at, so the
    // allocation-free setSampleRate() can re-derive it from processBlock.
    const int maxFactor = oversamplingFactorForIndex(kMaxOversamplingStages);
    clipper.prepare(sampleRate, preparedBlockCapacity, maxFactor);

    // Adopt whatever factor the (possibly just-restored) parameter holds.
    const int osIndex = juce::jlimit(0, kMaxOversamplingStages,
        int(apvts.getRawParameterValue("oversamplingFactor")->load()));
    const int osFactor = oversamplingFactorForIndex(osIndex);
    activeOversamplingIndex.store(osIndex, std::memory_order_relaxed);
    clipper.setSampleRate(sampleRate * double(osFactor), osFactor);

    setLatencySamples(computeTotalLatency());

    const int capSamples = int(std::ceil(sampleRate * kSmartMasterCaptureSeconds));
    if (smartMasterCapture.getNumSamples() != capSamples)
        smartMasterCapture.setSize(2, capSamples, false, true, true);
    smartMasterCaptureActive.store(false, std::memory_order_relaxed);
    smartMasterCaptureWritePos.store(0, std::memory_order_relaxed);
    smartMasterCaptureDone.store(false, std::memory_order_relaxed);

    demoAudioReady.store(false, std::memory_order_release);
    demoAudioPlaying.store(false, std::memory_order_release);
    demoAudio.clear();
}

void VisualCompProcessor::releaseResources() {}

bool VisualCompProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto& mainIn  = layouts.getMainInputChannelSet();
    const auto& mainOut = layouts.getMainOutputChannelSet();
    if (mainOut != mainIn) return false;
    if (mainIn != juce::AudioChannelSet::mono() &&
        mainIn != juce::AudioChannelSet::stereo())
        return false;
    const auto& sc = layouts.getChannelSet(true, 1);
    if (!sc.isDisabled() &&
        sc != juce::AudioChannelSet::mono() &&
        sc != juce::AudioChannelSet::stereo())
        return false;
    return true;
}

void VisualCompProcessor::processBlock(juce::AudioBuffer<float>& buffer,
                                       juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int numSamples  = buffer.getNumSamples();
    const int numChannels = buffer.getNumChannels();
    if (numSamples == 0 || numChannels == 0) return;

    // buffer.getNumChannels() counts EVERY channel the host handed us: the
    // main bus *plus* the optional stereo sidechain input. With a host that
    // has the sidechain enabled (FL Studio does as soon as one is routed)
    // that is 4, not 2 -- only the first two channels are the main bus.
    // Everything below that processes, meters, blends or captures audio must
    // therefore iterate mainChannels, never numChannels. Using numChannels
    // wrote compressed audio over the host's sidechain input and, worse,
    // overran the fixed-size chSamples[2] in the main per-sample loop below,
    // corrupting the stack (STATUS_STACK_BUFFER_OVERRUN / access violation,
    // typically surfacing far from here). numChannels stays in use only for
    // the sidechain bus's own bounds check further down, where the whole
    // buffer's channel count is exactly what's wanted.
    //
    // Deriving this as jmin(numChannels, 2) was still wrong for a *mono* main
    // bus (isBusesLayoutSupported accepts mono as well as stereo): mono main +
    // stereo sidechain is a 3-channel buffer, so that formula returned 2 and
    // channel 1 -- the sidechain's left channel -- was read and written as if
    // it were the main bus's right. Ask the bus layout how wide the main bus
    // actually is instead, and only then clamp to the buffer we were handed
    // and to the 2-channel stereo maximum the per-sample stage assumes.
    const int mainChannels = juce::jlimit(1, 2,
        juce::jmin(juce::jmin(getMainBusNumInputChannels(),
                              getMainBusNumOutputChannels()),
                   numChannels));

    if (demoAudioPlaying.load(std::memory_order_acquire)
        && demoAudioReady.load(std::memory_order_acquire)
        && demoAudio.getNumSamples() > 1)
    {
        const int demoFrames = demoAudio.getNumSamples();
        for (int s = 0; s < numSamples; ++s)
        {
            const int i0 = int(demoReadPosition) % demoFrames;
            const int i1 = (i0 + 1) % demoFrames;
            const float frac = float(demoReadPosition - std::floor(demoReadPosition));
            for (int ch = 0; ch < mainChannels; ++ch)
            {
                const int sourceCh = juce::jmin(ch, demoAudio.getNumChannels() - 1);
                const float a = demoAudio.getSample(sourceCh, i0);
                const float b = demoAudio.getSample(sourceCh, i1);
                buffer.setSample(ch, s, a + (b - a) * frac);
            }
            demoReadPosition += demoReadIncrement;
            while (demoReadPosition >= demoFrames) demoReadPosition -= demoFrames;
        }
    }

    // ── Bypass: pass input unchanged, reset metering ──────────────────────────
    if (bypassed.load(std::memory_order_relaxed))
    {
        gainReductionDb.store(0.0f,   std::memory_order_relaxed);
        currentInputLevelDb.store(-100.0f, std::memory_order_relaxed);
        return;
    }

    // ── Parameter snapshot ────────────────────────────────────────────────────
    const float mixAmt      = apvts.getRawParameterValue("mix")->load();
    const float eqMixAmt    = apvts.getRawParameterValue("eqMix")->load();
    const float attackMs    = apvts.getRawParameterValue("attack")->load();
    const float releaseMs   = apvts.getRawParameterValue("release")->load();
    const float thresholdDb = apvts.getRawParameterValue("threshold")->load();
    const float kneeDb      = apvts.getRawParameterValue("knee")->load();
    const float ratio       = apvts.getRawParameterValue("ratio")->load();
    const float gainInDb    = apvts.getRawParameterValue("gainIn")->load();
    const float gainOutDb   = apvts.getRawParameterValue("gainOut")->load();
    const bool  limiterOn   = apvts.getRawParameterValue("limiter")->load() > 0.5f;

    const float inputLinear  = juce::Decibels::decibelsToGain(gainInDb);
    const float outputLinear = juce::Decibels::decibelsToGain(gainOutDb);

    const bool     useSidechain  = sidechainEnabled.load(std::memory_order_relaxed);
    const CompMode mode          = static_cast<CompMode>(compMode.load(std::memory_order_relaxed));
    const bool     useAutoGain   = autoGainEnabled.load(std::memory_order_relaxed);

    // ── Mode-adjusted timing ──────────────────────────────────────────────────
    float effAttack  = attackMs;
    float effRelease = releaseMs;
    switch (mode)
    {
        case CompMode::FET:
            effAttack  = juce::jmin(attackMs,  2.0f);
            effRelease = juce::jmax(releaseMs, 20.0f);
            break;
        case CompMode::Optical:
            effAttack  = juce::jmax(attackMs,  30.0f);
            effRelease = juce::jmax(releaseMs, 100.0f);
            break;
        case CompMode::Tube:
            effAttack  = juce::jmax(attackMs,  50.0f);
            effRelease = juce::jmax(releaseMs, 200.0f);
            break;
        default: break;
    }

    const float attackCoeff  = std::exp(-1.0f / float(currentSampleRate * effAttack  * 0.001));
    const float releaseCoeff = std::exp(-1.0f / float(currentSampleRate * effRelease * 0.001));
    const float fetDrive     = (mode == CompMode::FET)
                             ? 0.28f + gainInDb * 0.006f
                             : 0.18f + gainInDb * 0.003f;

    // ── Auto-gain: measure INPUT RMS before any modification ──────────────────
    if (useAutoGain)
    {
        float sumSq = 0.0f;
        for (int ch = 0; ch < mainChannels; ++ch)
            for (int i = 0; i < numSamples; ++i) {
                const float s = buffer.getSample(ch, i) * inputLinear;
                sumSq += s * s;
            }
        const float inRms = sumSq > 0.0f
            ? std::sqrt(sumSq / float(mainChannels * numSamples)) : 0.0f;
        const float rmsC = std::exp(-float(numSamples) / float(currentSampleRate * 0.5));
        inputRmsSmooth = rmsC * inputRmsSmooth + (1.0f - rmsC) * inRms;
    }

    // ── Dry capture ───────────────────────────────────────────────────────────
    if (mixAmt < 0.9999f)
    {
        dryBuffer.setSize(mainChannels, numSamples, false, false, true);
        for (int ch = 0; ch < mainChannels; ++ch)
            dryBuffer.copyFrom(ch, 0, buffer, ch, 0, numSamples);
    }

    // ── Input waveform capture (pre-compression) ──────────────────────────────
    monoMixBuffer.setSize(1, numSamples, false, false, true);
    monoMixBuffer.clear();
    const float inScale = inputLinear / float(mainChannels);
    for (int ch = 0; ch < mainChannels; ++ch)
        monoMixBuffer.addFrom(0, 0, buffer, ch, 0, numSamples, inScale);
    inputWaveform.push(monoMixBuffer.getReadPointer(0), numSamples);

    // ── Smart Master+ capture (raw pre-processing input, up to ~9s) ───────────
    // Armed by VisualCompEditor::beginSmartMasterCapture; runs until the
    // buffer fills, then flags done for the GUI's timer to notice. Copies
    // straight from the untouched input `buffer` -- nothing below this point
    // has modified it yet -- so the wizard analyzes exactly what came in.
    if (smartMasterCaptureActive.load(std::memory_order_relaxed))
    {
        int pos = smartMasterCaptureWritePos.load(std::memory_order_relaxed);
        const int cap = smartMasterCapture.getNumSamples();
        const int toCopy = juce::jmin(numSamples, cap - pos);
        if (toCopy > 0)
        {
            for (int ch = 0; ch < 2; ++ch)
            {
                const int srcCh = juce::jmin(ch, mainChannels - 1);
                smartMasterCapture.copyFrom(ch, pos, buffer, srcCh, 0, toCopy);
            }
            pos += toCopy;
            smartMasterCaptureWritePos.store(pos, std::memory_order_relaxed);
        }
        if (pos >= cap)
        {
            smartMasterCaptureActive.store(false, std::memory_order_relaxed);
            smartMasterCaptureDone.store(true, std::memory_order_relaxed);
        }
    }

    // ── Sidechain bus ─────────────────────────────────────────────────────────
    // Defensive bounds check before touching the sidechain bus: JUCE's
    // Bus::getBusBuffer() does raw pointer arithmetic on the channel-pointer
    // array (buffer.getArrayOfWritePointers() + channelOffset) with NO bounds
    // checking against the buffer we were actually handed. Some hosts (FL
    // Studio observed, when the sidechain input is selected/enabled) report
    // the sidechain bus as active in the layout but call processBlock with a
    // buffer that doesn't actually have channels allocated for it -- calling
    // getBusBuffer() unconditionally then reads channel pointers from past
    // the end of the array and dereferences them, corrupting memory and
    // crashing (typically far from this code, e.g. a null/garbage vtable
    // call). Verify the sidechain bus's channel range actually fits within
    // the buffer we were given before ever calling getBusBuffer() on it.
    const int scChannelOffset = getChannelIndexInProcessBlockBuffer(true, 1, 0);
    const int scChannelCount  = getChannelCountOfBus(true, 1);
    const bool scBufferOk     = scChannelCount > 0
                              && (scChannelOffset + scChannelCount) <= numChannels;
    juce::AudioBuffer<float> scBus = scBufferOk ? getBusBuffer(buffer, true, 1)
                                                 : juce::AudioBuffer<float>();
    const bool hasSC = useSidechain && scBufferOk;

    // ── Sidechain envelope → visualization buffer ─────────────────────────────
    // Always push so sidechainWaveform stays current; display reads it only when SC on.
    {
        scEnvBuf.setSize(1, numSamples, false, false, true);
        auto* envPtr = scEnvBuf.getWritePointer(0);
        // 1 ms attack, 200 ms release — smooth ballistic envelope follower
        const float scAtk = std::exp(-1.0f / float(currentSampleRate * 0.001));
        const float scRel = std::exp(-1.0f / float(currentSampleRate * 0.200));
        for (int i = 0; i < numSamples; ++i)
        {
            float peak = 0.0f;
            if (hasSC)
                for (int ch = 0; ch < scBus.getNumChannels(); ++ch)
                    peak = std::max(peak, std::abs(scBus.getSample(ch, i)));
            scEnvelope = (peak > scEnvelope)
                ? scAtk * scEnvelope + (1.0f - scAtk) * peak
                : scRel * scEnvelope + (1.0f - scRel) * peak;
            envPtr[i] = scEnvelope;
        }
        sidechainWaveform.push(envPtr, numSamples);
    }

    float blockPeak = 0.0f;

    // Coefficients for the parametric EQ are only rebuilt when the GUI has
    // actually changed a node (non-blocking; see ParametricEq::maybeUpdateCoefficients).
    eq.maybeUpdateCoefficients();

    // ── Multiband mode ─────────────────────────────────────────────────────────
    // Recompute each *linked* node's own filter once per block using a
    // dynamically-reduced gain (its static gainDb minus that band's own,
    // already-smoothed gain reduction) — this is what turns a linked EQ node
    // into its own independent dynamic-EQ-style compression band. Runs at
    // block rate (not sample rate) since gain reduction only needs to track
    // program material on the same timescale as the attack/release envelope
    // it's derived from, not update every sample.
    const bool multiband = multibandEnabled.load(std::memory_order_relaxed);
    if (multiband)
    {
        const bool forceDemo = debugForceBandGrDemo.load(std::memory_order_relaxed);
        for (int b = 0; b < kMaxEqNodes; ++b)
        {
            if (!eq.isLinked(b))
            {
                bandGrDb[size_t(b)].store(0.0f, std::memory_order_relaxed);
                continue;
            }
            const float bandDetDb = juce::Decibels::gainToDecibels(
                  juce::jmax(1e-6f, eq.bandEnvelopeFor(b)));
            const float bandGr = (forceDemo && b == 0) ? -6.0f
                : clampedDynamicGrDb(eq.upwardFor(b), bandDetDb, eq.thresholdDbFor(b),
                                     eq.kneeDbFor(b), eq.ratioFor(b), eq.rangeDbFor(b));
            eq.applyDynamicBandGain(b, bandGr);
            bandGrDb[size_t(b)].store(bandGr, std::memory_order_relaxed);
        }
    }
    else
    {
        for (auto& bg : bandGrDb) bg.store(0.0f, std::memory_order_relaxed);
    }

    // ── Main processing loop ──────────────────────────────────────────────────
    for (int i = 0; i < numSamples; ++i)
    {
        float chSamples[2] = { 0.0f, 0.0f };
        for (int ch = 0; ch < mainChannels; ++ch)
        {
            const float raw = buffer.getSample(ch, i) * inputLinear;
            float sat;
            switch (mode)
            {
                case CompMode::FET:  sat = fetSaturate (raw, fetDrive);         break;
                case CompMode::Tube: sat = tubeSaturate(raw, fetDrive * 0.6f);  break;
                default:             sat = raw;                                  break;
            }
            chSamples[ch] = sat;
        }

        // Parametric EQ (tone-shaping) also drives the multiband-aware
        // detector: any node marked "linked" measures its own band's energy
        // here, independent of whether the node's own gain is boosting/cutting.
        float l = chSamples[0];
        float r = (mainChannels > 1) ? chSamples[1] : chSamples[0];
        const float eqDryL = l, eqDryR = r;
        eq.processSample(l, r);
        // EQ-only dry/wet blend -- independent of the overall Mix knob's
        // end-of-block blend below. Local per-sample floats already hold
        // both the dry (pre-EQ) and wet (post-EQ) values, so this needs no
        // separate full-buffer dry copy the way the global mix does.
        if (eqMixAmt < 0.9999f)
        {
            l = l * eqMixAmt + eqDryL * (1.0f - eqMixAmt);
            r = r * eqMixAmt + eqDryR * (1.0f - eqMixAmt);
        }
        buffer.setSample(0, i, l);
        if (mainChannels > 1) buffer.setSample(1, i, r);

        const float mainPeak = (mainChannels > 1) ? juce::jmax(std::abs(l), std::abs(r))
                                                  : std::abs(l);
        blockPeak = std::max(blockPeak, mainPeak);

        float detectPeak = mainPeak;
        if (hasSC)
        {
            float scPeak = 0.0f;
            for (int ch = 0; ch < scBus.getNumChannels(); ++ch)
                scPeak = std::max(scPeak, std::abs(scBus.getSample(ch, i)));
            detectPeak = scPeak;
        }

        float detDb = detectPeak > 1e-7f
            ? juce::Decibels::gainToDecibels(detectPeak) : -140.0f;

        // Single-band mode only: a hot linked EQ band boosts the broadband
        // detector so compression can trigger even when the overall peak is
        // under threshold. In multiband mode each linked band already gets
        // its own independent compression (see above), so this trick is
        // skipped to avoid double-compressing that band's energy.
        if (!multiband && eq.dominantLinkedBand() >= 0)
            detDb = juce::jmax(detDb, eq.dominantLinkedBandDb());

        const float grDb = kneeRatioGrDb(detDb, thresholdDb, kneeDb, ratio);

        switch (mode)
        {
            case CompMode::VCA:
            case CompMode::FET:
            {
                const float c = (grDb < envelope) ? attackCoeff : releaseCoeff;
                envelope = c * envelope + (1.0f - c) * grDb;
                break;
            }
            case CompMode::Optical:
            {
                const float targetLight = juce::jlimit(0.0f, 1.0f, -grDb / 20.0f);
                if (targetLight > opticalState)
                    opticalState = attackCoeff  * opticalState + (1.0f - attackCoeff)  * targetLight;
                else
                    opticalState = releaseCoeff * opticalState + (1.0f - releaseCoeff) * targetLight;
                envelope = -opticalState * 20.0f * (1.0f + opticalState * 0.5f);
                break;
            }
            case CompMode::Tube:
            {
                const float depth  = juce::jlimit(0.0f, 1.0f, -grDb / 20.0f);
                tubeMu             = 1.0f + depth * 1.8f;
                const float tubeGr = grDb * tubeMu;
                const float c      = (tubeGr < envelope) ? attackCoeff : releaseCoeff;
                envelope           = c * envelope + (1.0f - c) * tubeGr;
                break;
            }
        }

        const float compGain = juce::Decibels::decibelsToGain(envelope) * outputLinear;
        for (int ch = 0; ch < mainChannels; ++ch)
        {
            const float compressed = buffer.getSample(ch, i) * compGain;
            float out;
            if (limiterOn)
            {
                out = juce::jlimit(-1.0f, 1.0f,
                    (mode == CompMode::Tube)
                        ? tubeSaturate(compressed, 0.08f)
                        : fetSaturate (compressed, 0.08f));
            }
            else
            {
                switch (mode)
                {
                    case CompMode::FET:  out = fetSaturate (compressed, 0.06f); break;
                    case CompMode::Tube: out = tubeSaturate(compressed, 0.10f); break;
                    default:             out = compressed;                       break;
                }
            }
            buffer.setSample(ch, i, out);
        }
    }

    // ── Dry/wet blend ─────────────────────────────────────────────────────────
    if (mixAmt < 0.9999f)
    {
        const float wet = mixAmt, dry = 1.0f - mixAmt;
        for (int ch = 0; ch < mainChannels; ++ch)
            for (int i = 0; i < numSamples; ++i)
                buffer.setSample(ch, i,
                    buffer.getSample(ch, i) * wet + dryBuffer.getSample(ch, i) * dry);
    }

    // ── Auto-gain: measure post-compression OUTPUT (before applying makeup) ───
    if (useAutoGain)
    {
        float sumSq = 0.0f;
        for (int ch = 0; ch < mainChannels; ++ch)
            for (int i = 0; i < numSamples; ++i) {
                const float s = buffer.getSample(ch, i);
                sumSq += s * s;
            }
        const float outRms = sumSq > 0.0f
            ? std::sqrt(sumSq / float(mainChannels * numSamples)) : 0.0f;

        const float rmsC = std::exp(-float(numSamples) / float(currentSampleRate * 0.5));
        outputRmsSmooth = rmsC * outputRmsSmooth + (1.0f - rmsC) * outRms;

        if (inputRmsSmooth > 1e-6f && outputRmsSmooth > 1e-6f)
        {
            // Target makeup = ratio of input to (pre-makeup) output level, clamped to [0, 24] dB
            const float targetAg = juce::jlimit(0.0f, 24.0f,
                juce::Decibels::gainToDecibels(inputRmsSmooth / outputRmsSmooth));
            // Smooth toward target over ~300 ms to avoid abrupt jumps
            const float agC = std::exp(-float(numSamples) / float(currentSampleRate * 0.3));
            autoGainDb = agC * autoGainDb + (1.0f - agC) * targetAg;
        }
        else if (outputRmsSmooth <= 1e-6f)
        {
            // Silence — slowly decay auto-gain toward 0 so it doesn't latch
            const float agC = std::exp(-float(numSamples) / float(currentSampleRate * 1.0));
            autoGainDb = agC * autoGainDb;
        }

        // Apply auto makeup gain to the buffer
        const float agLinear = juce::Decibels::decibelsToGain(autoGainDb);
        for (int ch = 0; ch < mainChannels; ++ch)
            for (int i = 0; i < numSamples; ++i)
                buffer.setSample(ch, i, buffer.getSample(ch, i) * agLinear);
    }
    else
    {
        // When disabled, reset smoothers so re-enabling ramps up cleanly
        autoGainDb      = 0.0f;
        inputRmsSmooth  = 0.0f;
        outputRmsSmooth = 0.0f;
    }

    // ── Final-stage clipping + post-output loudness metering ─────────────────
    // Both the clip shaper and the lookahead limiter run *inside* the
    // oversampler when one is engaged: clipping is the one nonlinearity in the
    // chain that generates harmonics above Nyquist, and running it at 2/4/8x
    // pushes those aliases out where the downsampling filter can remove them.
    // Metering deliberately stays outside, at the base rate, so the numbers on
    // screen describe what actually leaves the plugin.
    {
        const ClipMode cm = static_cast<ClipMode>(clipMode.load(std::memory_order_relaxed));

        // Adopt a new factor if the parameter moved since the last block. Both
        // steps here are allocation-free (the oversamplers were built in
        // prepareToPlay; clipper.prepare() reserved the delay line for the
        // largest factor), so this is safe on the audio thread.
        const int wantedIdx = juce::jlimit(0, kMaxOversamplingStages,
            int(apvts.getRawParameterValue("oversamplingFactor")->load()));

        if (wantedIdx != activeOversamplingIndex.load(std::memory_order_relaxed))
        {
            const int factor = oversamplingFactorForIndex(wantedIdx);
            clipper.setSampleRate(currentSampleRate * double(factor), factor);
            if (auto* os = oversamplers[size_t(wantedIdx)].get())
                os->reset();
            activeOversamplingIndex.store(wantedIdx, std::memory_order_relaxed);
            // Reporting the new latency to the host is not real-time safe --
            // hand it to the message thread.
            triggerAsyncUpdate();
        }

        // Only the main output channels are oversampled -- the extra
        // sidechain channels (see mainChannels above) neither want clipping
        // nor fit the 2-channel oversamplers.
        auto* os = (wantedIdx > 0 && numSamples <= preparedBlockCapacity)
                     ? oversamplers[size_t(wantedIdx)].get() : nullptr;

        if (os == nullptr)
        {
            // 1x: bypass the oversampler entirely rather than paying for a
            // dummy stage.
            for (int i = 0; i < numSamples; ++i)
            {
                float l = buffer.getSample(0, i);
                float r = (mainChannels > 1) ? buffer.getSample(1, i) : l;
                clipper.processSample(l, r, cm);
                buffer.setSample(0, i, l);
                if (mainChannels > 1) buffer.setSample(1, i, r);
                loudness.pushSample(l, r);
            }
        }
        else
        {
            auto mainBlock = juce::dsp::AudioBlock<float>(buffer)
                                 .getSubsetChannelBlock(0, size_t(mainChannels))
                                 .getSubBlock(0, size_t(numSamples));

            auto upBlock = os->processSamplesUp(mainBlock);

            const int   upSamples = int(upBlock.getNumSamples());
            float*      upL = upBlock.getChannelPointer(0);
            float*      upR = (upBlock.getNumChannels() > 1)
                                  ? upBlock.getChannelPointer(1) : nullptr;

            for (int i = 0; i < upSamples; ++i)
            {
                float l = upL[i];
                float r = (upR != nullptr) ? upR[i] : l;
                clipper.processSample(l, r, cm);
                upL[i] = l;
                if (upR != nullptr) upR[i] = r;
            }

            os->processSamplesDown(mainBlock);

            // Meter the downsampled result, not the oversampled one.
            const float* outL = buffer.getReadPointer(0);
            const float* outR = (mainChannels > 1) ? buffer.getReadPointer(1) : outL;
            for (int i = 0; i < numSamples; ++i)
                loudness.pushSample(outL[i], outR[i]);
        }

        meterPeakDb.store(loudness.peakDb(), std::memory_order_relaxed);
        meterRmsDb.store(loudness.rmsDb(), std::memory_order_relaxed);
        meterMomLufs.store(loudness.momentaryLufs(), std::memory_order_relaxed);
        meterShortLufs.store(loudness.shortTermLufs(), std::memory_order_relaxed);

        // Feed into smooth meter atomics for butter-smooth 120Hz interpolation
        smoothMeterPeak.update(loudness.peakDb());
        smoothMeterRms.update(loudness.rmsDb());
        smoothMeterLufs.update(loudness.shortTermLufs());
    }

    // ── Output waveform capture (post-clip: matches what is actually heard) ──
    monoMixBuffer.clear();
    const float outScale = 1.0f / float(mainChannels);
    for (int ch = 0; ch < mainChannels; ++ch)
        monoMixBuffer.addFrom(0, 0, buffer, ch, 0, numSamples, outScale);
    outputWaveform.push(monoMixBuffer.getReadPointer(0), numSamples);

    // ── Metering ──────────────────────────────────────────────────────────────
    gainReductionDb.store(envelope, std::memory_order_relaxed);
    const float inputDb = blockPeak > 1e-7f
        ? juce::Decibels::gainToDecibels(blockPeak) : -100.0f;
    currentInputLevelDb.store(inputDb, std::memory_order_relaxed);
    activeEqBand.store(eq.dominantLinkedBand(), std::memory_order_relaxed);
}

void VisualCompProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    state.setProperty("compMode",   compMode.load(std::memory_order_relaxed), nullptr);
    state.setProperty("clipMode",   clipMode.load(std::memory_order_relaxed), nullptr);
    state.setProperty("presetName",   currentPresetName,   nullptr);
    state.setProperty("presetAuthor", currentPresetAuthor, nullptr);
    // eqPanelOpen deliberately not saved — see setStateInformation, it's
    // never read back, so always starts closed.
    state.setProperty("curveGrPanelOpen", curveGrPanelOpen, nullptr);
    // multibandEnabled deliberately not saved — see setStateInformation,
    // it's never read back, so it's always on regardless of what an older
    // saved project had.

    for (int i = 0; i < kMaxEqNodes; ++i)
    {
        const auto n = eq.getNode(i);
        const juce::String p = "eq" + juce::String(i) + "_";
        state.setProperty(p + "enabled", n.enabled, nullptr);
        state.setProperty(p + "linked",  n.linked,  nullptr);
        state.setProperty(p + "freq",    n.freqHz,  nullptr);
        state.setProperty(p + "gain",    n.gainDb,  nullptr);
        state.setProperty(p + "q",       n.q,       nullptr);
        state.setProperty(p + "type",    n.type,    nullptr);
        state.setProperty(p + "attackMs",  n.attackMs,  nullptr);
        state.setProperty(p + "releaseMs", n.releaseMs, nullptr);
        state.setProperty(p + "thresholdDb", n.thresholdDb, nullptr);
        state.setProperty(p + "kneeDb",      n.kneeDb,      nullptr);
        state.setProperty(p + "ratio",       n.ratio,       nullptr);
        state.setProperty(p + "rangeDb",     n.rangeDb,     nullptr);
        state.setProperty(p + "bwLowOct",    n.bwLowOct,    nullptr);
        state.setProperty(p + "bwHighOct",   n.bwHighOct,   nullptr);
        state.setProperty(p + "upward",      n.upward,      nullptr);
    }

    // Dynamic Island position persistence per-node
    for (int i = 0; i < 8; ++i)
    {
        const juce::String p = "islandNode" + juce::String(i) + "_";
        state.setProperty(p + "hasPosition", islandPositions[i].hasPosition, nullptr);
        if (islandPositions[i].hasPosition)
        {
            state.setProperty(p + "x", islandPositions[i].x, nullptr);
            state.setProperty(p + "y", islandPositions[i].y, nullptr);
        }
    }

    if (auto xml = state.createXml())
        copyXmlToBinary(*xml, destData);
}

void VisualCompProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary(data, sizeInBytes))
        if (xml->hasTagName(apvts.state.getType()))
        {
            auto state = juce::ValueTree::fromXml(*xml);
            apvts.replaceState(state);
            compMode.store(int(state.getProperty("compMode", 0)), std::memory_order_relaxed);
            clipMode.store(int(state.getProperty("clipMode", 0)), std::memory_order_relaxed);
            currentPresetName   = state.getProperty("presetName", "Mastering Glue").toString();
            currentPresetAuthor = state.getProperty("presetAuthor", "").toString();
            // Deliberately not restored from state — the docked EQ panel is a
            // transient view, not song data, and should always start closed
            // regardless of whether an earlier session (or this same project,
            // last time it was saved) happened to leave it open.
            eqPanelOpen = false;
            curveGrPanelOpen = bool(state.getProperty("curveGrPanelOpen", false));
            // Deliberately not restored from state — multiband mode is always
            // on now (no user-facing toggle any more), so an older project
            // that saved it as off must not be able to turn it back off.
            multibandEnabled.store(true, std::memory_order_relaxed);

            for (int i = 0; i < kMaxEqNodes; ++i)
            {
                const juce::String p = "eq" + juce::String(i) + "_";
                EqNodeState n;
                n.enabled = bool(state.getProperty(p + "enabled", false));
                n.linked  = bool(state.getProperty(p + "linked",  false));
                n.freqHz  = float(state.getProperty(p + "freq",   1000.0));
                n.gainDb  = float(state.getProperty(p + "gain",   0.0));
                n.q       = float(state.getProperty(p + "q",      0.9));
                n.type    = int  (state.getProperty(p + "type",   0));
                n.attackMs  = float(state.getProperty(p + "attackMs",  0.2));
                n.releaseMs = float(state.getProperty(p + "releaseMs", 45.0));
                n.upward      = bool (state.getProperty(p + "upward",       false));
                // Threshold is downward-only (-60..0, the knob's own floor —
                // see setupThresholdKnobRange() in EqEngine.h); clamp in case
                // this is an older project saved with a value outside that
                // (the range has moved a few times: +/-96, then -90..0, now
                // -60..0). rangeDb's fallback (for projects saved before
                // Range existed at all) uses upward's already-loaded
                // direction at max magnitude, so old linked bands keep doing
                // roughly as much as they used to rather than silently going
                // inert at the new default of 0dB.
                n.thresholdDb = juce::jlimit(-60.0f, 0.0f,
                                    float(state.getProperty(p + "thresholdDb", -20.0)));
                n.kneeDb      = float(state.getProperty(p + "kneeDb",        6.0));
                n.ratio       = float(state.getProperty(p + "ratio",         2.0));
                n.rangeDb     = float(state.getProperty(p + "rangeDb", n.upward ? 30.0 : -30.0));
                n.bwLowOct    = float(state.getProperty(p + "bwLowOct",      1.0));
                n.bwHighOct   = float(state.getProperty(p + "bwHighOct",     1.0));
                eq.setNode(i, n);
            }

            // Restore Dynamic Island positions per-node
            for (int i = 0; i < 8; ++i)
            {
                const juce::String p = "islandNode" + juce::String(i) + "_";
                islandPositions[i].hasPosition = bool(state.getProperty(p + "hasPosition", false));
                if (islandPositions[i].hasPosition)
                {
                    islandPositions[i].x = int(state.getProperty(p + "x", 0));
                    islandPositions[i].y = int(state.getProperty(p + "y", 0));
                }
            }
        }
}

juce::AudioProcessorEditor* VisualCompProcessor::createEditor()
{
    return new VisualCompEditor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new VisualCompProcessor();
}
